export const asset = (name) => `${import.meta.env.BASE_URL}assets/${name}`

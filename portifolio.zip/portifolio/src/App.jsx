import { useEffect } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Stats from './components/Stats'
import About from './components/About'
import Services from './components/Services'
import Experience from './components/Experience'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Education from './components/Education'
import Contact from './components/Contact'
import LetsDiscuss from './components/LetsDiscuss'
import Footer from './components/Footer'
import WhatsAppButton from './components/WhatsAppButton'
import Analytics from './components/Analytics'

export default function App() {
  useEffect(() => {
    const elements = document.querySelectorAll('.reveal')
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add('show')
      })
    }, { threshold: .12 })

    elements.forEach((element) => observer.observe(element))
    return () => observer.disconnect()
  }, [])

  return (
    <>
      <Analytics />
      <Header />
      <main>
        <Hero />
        <Stats />
        <About />
        <Services />
        <Experience />
        <Skills />
        <Projects />
        <Education />
        <Contact />
        <LetsDiscuss />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}

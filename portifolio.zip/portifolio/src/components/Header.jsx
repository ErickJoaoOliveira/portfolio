import { useEffect, useState } from 'react'

const links = [
  ['inicio', 'Início'],
  ['sobre', 'Sobre'],
  ['experiencia', 'Experiência'],
  ['projetos', 'Projetos'],
  ['habilidades', 'Habilidades'],
  ['formacao', 'Formação'],
  ['contato', 'Contato']
]

export default function Header() {
  const [active, setActive] = useState('inicio')

  useEffect(() => {
    const sections = links
      .map(([id]) => document.getElementById(id))
      .filter(Boolean)

    const observer = new IntersectionObserver((entries) => {
      const visible = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]
      if (visible?.target?.id) setActive(visible.target.id)
    }, { rootMargin: '-25% 0px -60% 0px', threshold: [0, .1, .25, .5] })

    sections.forEach((section) => observer.observe(section))
    return () => observer.disconnect()
  }, [])

  return (
    <header className="header">
      <div className="header-inner">
        <a href="#inicio" className="logo" onClick={() => setActive('inicio')}>
          ER<span>&lt;/&gt;</span>
        </a>

        <nav className="nav" aria-label="Navegação principal">
          {links.map(([id, label]) => (
            <a
              key={id}
              className={active === id ? 'active' : ''}
              href={`#${id}`}
              onClick={() => setActive(id)}
            >
              {label}
            </a>
          ))}
        </nav>

        <a href="#contato" className="talk">
          Vamos conversar <span>→</span>
        </a>
      </div>
    </header>
  )
}

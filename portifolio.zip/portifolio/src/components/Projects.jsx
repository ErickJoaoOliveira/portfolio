const projects = [
  {
    icon: '✈',
    title: 'Bot de Vendas no Telegram',
    text: 'Sistema automatizado de vendas via Telegram, com integração ao Mercado Pago para pagamentos via PIX, confirmação automática e liberação de acesso.',
    tags: ['Node.js', 'Express', 'Telegram API', 'Mercado Pago']
  },
  {
    icon: '▣',
    title: 'Plugin - Buscador de Produtos (Mercado Livre)',
    text: 'Plugin para WordPress que busca produtos do Mercado Livre usando a API oficial, exibe resultados por menor preço e gera links de afiliado automaticamente.',
    tags: ['WordPress', 'API Mercado Livre', 'PHP', 'JavaScript']
  }
]

export default function Projects() {
  return (
    <section className="content-section reveal" id="projetos">
      <div className="section-heading">
        <div className="section-kicker"><span></span>PROJETOS</div>
        <div className="section-side">// MEUS TRABALHOS</div>
      </div>

      <div className="projects-grid">
        {projects.map((project) => (
          <article className="project-card" key={project.title}>
            <div className="project-icon">{project.icon}</div>
            <div>
              <h4>{project.title}</h4>
              <p>{project.text}</p>
              <div className="project-tags">
                {project.tags.map((tag) => <span key={tag}>{tag}</span>)}
              </div>
              <a href="#contato">Ver mais detalhes →</a>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

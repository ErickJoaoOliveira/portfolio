import { useState } from 'react'
import { GitHubIcon, MailIcon } from './Icons'
import { buildContactPayload } from '../contactForm'
import { trackEvent } from '../analytics'

const initialForm = {
  name: '',
  email: '',
  subject: '',
  message: '',
  botField: ''
}

export default function Contact() {
  const [form, setForm] = useState(initialForm)
  const [status, setStatus] = useState({ type: '', message: '' })
  const [sending, setSending] = useState(false)

  const update = (event) => {
    const { name, value } = event.target
    setForm((current) => ({ ...current, [name]: value }))
  }

  const submit = async (event) => {
    event.preventDefault()

    // Honeypot: bots que preencherem esse campo não enviam.
    if (form.botField) return

    setSending(true)
    setStatus({ type: '', message: '' })

    try {
      const response = await fetch('/form-contact.html', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: buildContactPayload(form).toString()
      })

      if (!response.ok) {
        throw new Error(`Netlify Forms retornou ${response.status}`)
      }

      trackEvent('contact_submit', { method: 'netlify_form' })
      setForm(initialForm)
      setStatus({
        type: 'success',
        message: 'Mensagem enviada com sucesso. Obrigado pelo contato!'
      })
    } catch (error) {
      console.error('Erro no envio do formulário:', error)
      setStatus({
        type: 'error',
        message: 'Não foi possível enviar agora. Você também pode entrar em contato por e-mail ou WhatsApp.'
      })
    } finally {
      setSending(false)
    }
  }

  return (
    <section className="content-section contact-section reveal" id="contato">
      <div className="section-heading">
        <div className="section-kicker"><span></span>CONTATO</div>
        <div className="section-side">// VAMOS CONVERSAR?</div>
      </div>

      <div className="contact-grid">
        <div className="contact-copy">
          <h3>Vamos trabalhar <strong>juntos?</strong></h3>
          <p>
            Precisa de um desenvolvedor de sites ou programador para um projeto? Estou aberto a oportunidades
            de desenvolvimento web, criação de sites e soluções digitais.
          </p>

          <div className="contact-items">
            <span>✉ erickkoliveira93@gmail.com</span>
            <span>⌖ Pato Branco - PR</span>
          </div>

          <div className="contact-socials">
            <a
              href="https://github.com/ErickJoaoOliveira"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              onClick={() => trackEvent('github_click', { location: 'contact' })}
            >
              <GitHubIcon />
            </a>
            <a href="mailto:erickkoliveira93@gmail.com" aria-label="E-mail">
              <MailIcon />
            </a>
          </div>
        </div>

        <form
          className="contact-form"
          name="contact"
          method="POST"
          action="/thanks.html"
          data-netlify="true"
          data-netlify-honeypot="bot-field"
          onSubmit={submit}
        >
          <input type="hidden" name="form-name" value="contact" />

          <p className="form-honeypot" aria-hidden="true">
            <label>
              Não preencha este campo:
              <input
                name="botField"
                value={form.botField}
                onChange={update}
                tabIndex="-1"
                autoComplete="off"
              />
            </label>
          </p>

          <div className="form-row">
            <label>
              Nome
              <input
                name="name"
                value={form.name}
                onChange={update}
                type="text"
                placeholder="Seu nome"
                autoComplete="name"
                required
              />
            </label>

            <label>
              E-mail
              <input
                name="email"
                value={form.email}
                onChange={update}
                type="email"
                placeholder="seuemail@exemplo.com"
                autoComplete="email"
                required
              />
            </label>
          </div>

          <label>
            Assunto
            <input
              name="subject"
              value={form.subject}
              onChange={update}
              type="text"
              placeholder="Como posso ajudar?"
            />
          </label>

          <label>
            Mensagem
            <textarea
              name="message"
              value={form.message}
              onChange={update}
              rows="5"
              placeholder="Digite sua mensagem aqui..."
              required
            />
          </label>

          <button type="submit" disabled={sending}>
            {sending ? 'Enviando...' : 'Enviar mensagem →'}
          </button>

          {status.message && (
            <p
              className={`form-status ${status.type}`}
              role="status"
              aria-live="polite"
            >
              {status.message}
            </p>
          )}
        </form>
      </div>
    </section>
  )
}

export default function About() {
  return (
    <section className="content-section reveal" id="sobre">
      <div className="section-heading">
        <div className="section-kicker"><span></span>SOBRE MIM</div>
        <div className="section-side">// INFORMAÇÕES</div>
      </div>

      <div className="about-grid">
        <div className="about-copy">
          <h3>Transformo ideias<br />em <strong>soluções reais.</strong></h3>
          <p>
            Atuo como desenvolvedor de sites e programador Front-End, criando e evoluindo sites e aplicações
            web com foco em responsividade, desempenho e experiência do usuário. Tenho facilidade em aprender,
            sou analítico, orientado a resultados e gosto de resolver problemas.
          </p>
          <p>
            Também desenvolvo soluções para presença digital, integração de APIs e automações, buscando criar
            sites profissionais e sistemas web que gerem valor real para pessoas, empresas e negócios.
          </p>

          <div className="mini-pills">
            <span>⌖ Pato Branco - PR</span>
            <span>◉ Disponível para oportunidades</span>
          </div>
        </div>

        <div className="info-panel">
          <div className="info-row"><small>Nome</small><strong>Erick João Recalcatti de Oliveira</strong></div>
          <div className="info-row"><small>Idade</small><strong>20 anos</strong></div>
          <div className="info-row"><small>Localização</small><strong>Pato Branco - PR</strong></div>
          <div className="info-row"><small>E-mail</small><strong>erickkoliveira93@gmail.com</strong></div>
          <div className="info-row"><small>Disponibilidade</small><strong>Novas oportunidades</strong></div>
        </div>
      </div>
    </section>
  )
}

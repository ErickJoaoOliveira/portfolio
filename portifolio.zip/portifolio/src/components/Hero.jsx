import { asset } from '../utils'
import { GitHubIcon, MailIcon } from './Icons'

export default function Hero() {
  return (
    <section className="hero" id="inicio">
      <div className="dots dots-left"></div>
      <div className="dots dots-right"></div>

      <div className="hero-inner">
        <div className="copy">
          <div className="intro"><span></span>OLÁ, EU SOU</div>
          <div className="orange-line"></div>

          <h1>
            Erick João<br />
            <strong>Recalcatti</strong> de Oliveira
          </h1>

          <h2>Desenvolvedor de Sites | Programador Front-End | Desenvolvimento Web</h2>

          <p>
            Programador e desenvolvedor de sites com experiência na criação, manutenção e evolução de
            aplicações web responsivas. Atuação com Front-End, Angular, TypeScript, integração de APIs,
            bancos de dados e soluções digitais para empresas e projetos.
          </p>

          <div className="actions">
            <a className="primary" href="#projetos"><b>&lt;/&gt;</b> Ver meus projetos <span>→</span></a>
            <a className="secondary" href="#contato"><b>✉</b> Entrar em contato</a>
          </div>

          <div className="socials">
            <a href="https://github.com/ErickJoaoOliveira" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
              <GitHubIcon />
            </a>
            <a href="mailto:erickkoliveira93@gmail.com" aria-label="E-mail">
              <MailIcon />
            </a>
          </div>
        </div>

        <div className="visual">
          <div className="glow"></div>
          <div className="ring ring-a"></div>
          <div className="ring ring-b"></div>
          <div className="ring ring-c"></div>

          <img className="portrait" src={asset('erick.webp')} alt="Erick Oliveira" width="1371" height="1147" fetchPriority="high" decoding="async" />

          <div className="age">
            <strong>20+</strong>
            <b>anos</b>
            <i></i>
            <p>Construindo<br />soluções e<br />aprendendo sempre</p>
          </div>

          <div className="words">FOCO<br />DISCIPLINA<br />EVOLUÇÃO<br />RESULTADOS<i></i></div>

          <img className="signature" src={asset('assinatura.webp')} alt="Erick Oliveira - Desenvolvedor" width="2048" height="682" decoding="async" />
        </div>
      </div>
    </section>
  )
}

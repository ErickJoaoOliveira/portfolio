export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-brand">ER<span>&lt;/&gt;</span></div>
      <div className="footer-name">
        <strong>Erick João Recalcatti de Oliveira</strong>
        <span>Desenvolvedor Front-End | Desenvolvimento Web</span>
      </div>
      <div className="footer-copy">
        © 2026 Erick João Recalcatti de Oliveira.<br />
        Todos os direitos reservados.
      </div>
    </footer>
  )
}

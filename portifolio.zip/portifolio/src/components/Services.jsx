import { useState } from 'react'
import { asset } from '../utils'

const leftServices = [
  {
    id: 1,
    icon: '</>',
    title: 'Desenvolvimento de Sites',
    text: 'Criação de sites profissionais, responsivos e modernos, com foco em performance, usabilidade e experiência do usuário.'
  },
  {
    id: 2,
    icon: '▧',
    title: 'Integração de APIs',
    text: 'Integração com APIs REST, bancos de dados e serviços externos para conectar diferentes soluções.'
  }
]

const rightServices = [
  {
    id: 3,
    icon: '▣',
    title: 'Suporte e Manutenção',
    text: 'Correção de bugs, testes, melhorias contínuas e suporte técnico em ambientes de produção.'
  },
  {
    id: 4,
    icon: '▥',
    title: 'Soluções Inteligentes',
    text: 'Uso de Inteligência Artificial para acelerar processos e otimizar o desenvolvimento de software.'
  }
]

function ServiceCard({ service }) {
  return (
    <div className="svc-card">
      <div className="service-icon">{service.icon}</div>
      <span className="service-number">{String(service.id).padStart(2, '0')}</span>
      <h4>{service.title}</h4>
      <p>{service.text}</p>
    </div>
  )
}

function Trigger({ service, side, activate }) {
  return (
    <button
      className="svc-trigger"
      type="button"
      aria-label={`Mostrar serviço ${service.title}`}
      onMouseEnter={activate}
      onFocus={activate}
      onClick={activate}
    >
      {side === 'right' && <span className="svc-dot"></span>}
      {side === 'right' && <span className="svc-line"></span>}

      <span className="svc-label">{service.title}</span>
      <span className="svc-number">{String(service.id).padStart(2, '0')}</span>

      {side === 'left' && <span className="svc-line"></span>}
      {side === 'left' && <span className="svc-dot"></span>}
    </button>
  )
}

function Side({ services, side }) {
  const [active, setActive] = useState(null)

  return (
    <div className={`svc-side svc-${side}`} onMouseLeave={() => setActive(null)}>
      {services.map((service) => (
        <div className={`svc-row ${active === service.id ? 'active' : ''}`} key={service.id}>
          {side === 'left' && <ServiceCard service={service} />}
          <Trigger service={service} side={side} activate={() => setActive(service.id)} />
          {side === 'right' && <ServiceCard service={service} />}
        </div>
      ))}
    </div>
  )
}

export default function Services() {
  return (
    <section className="content-section reveal" id="servicos">
      <div className="section-heading">
        <div className="section-kicker"><span></span>O QUE EU FAÇO</div>
        <div className="section-side">// SERVIÇOS</div>
      </div>

      <div className="svc-layout">
        <Side services={leftServices} side="left" />

        <div className="svc-center">
          <div className="svc-glow"></div>
          <img src={asset('erick-services-figure.webp')} alt="Ilustração de Erick ao centro da seção de serviços" width="1024" height="1536" loading="lazy" decoding="async" />
          <div className="svc-quote svc-quote-top">DISCIPLINA<br /><strong>GERA</strong><br />LIBERDADE.</div>
          <div className="svc-quote svc-quote-bottom">EVOLUÇÃO<br />É UM PROCESSO.<br /><strong>NÃO UM EVENTO.</strong></div>
        </div>

        <Side services={rightServices} side="right" />
      </div>
    </section>
  )
}

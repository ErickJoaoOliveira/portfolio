const leftSkills = [
  'HTML', 'CSS', 'JavaScript', 'TypeScript', 'Angular',
  'Desenvolvimento Front-End', 'Desenvolvimento Web', 'Integração de APIs',
  'APIs REST', 'CRUD', 'Context API', 'Microfrontends'
]

const rightSkills = [
  'UX', 'Arquitetura de sistemas escaláveis', 'Banco de Dados', 'SQL',
  'Bancos relacionais e não relacionais', 'Testes manuais', 'Automação de testes',
  'Testes unitários', 'Homologação e testes', 'Metodologias Ágeis', 'Clean Code',
  'Inteligência Artificial aplicada ao desenvolvimento'
]

const techs = [
  ['API', 'APIs REST'],
  ['</>', 'Clean Code'],
  ['AI', 'IA'],
  ['MF', 'Microfrontends'],
  ['AG', 'Metodologias Ágeis']
]

export default function Skills() {
  return (
    <section className="content-section reveal" id="habilidades">
      <div className="section-heading">
        <div className="section-kicker"><span></span>HABILIDADES E COMPETÊNCIAS</div>
        <div className="section-side">// TECNOLOGIAS</div>
      </div>

      <div className="skills-layout">
        <div className="skills-lists">
          <ul>{leftSkills.map((skill) => <li key={skill}>{skill}</li>)}</ul>
          <ul>{rightSkills.map((skill) => <li key={skill}>{skill}</li>)}</ul>
        </div>

        <div className="tech-panel">
          <h4>TECNOLOGIAS EM DESTAQUE</h4>
          <div className="tech-grid">
            {techs.map(([abbr, name]) => (
              <div className="tech-card" key={name}><b>{abbr}</b><span>{name}</span></div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

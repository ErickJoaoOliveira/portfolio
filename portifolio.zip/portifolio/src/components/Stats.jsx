const stats = [
  ['</>', '10+', 'Projetos concluídos'],
  ['▣', '3+', 'Empresas e experiências'],
  ['◇', '20+', 'Tecnologias e ferramentas'],
  ['▥', '100%', 'Foco em resultados']
]

export default function Stats() {
  return (
    <section className="stats-section reveal">
      <div className="stats-grid">
        {stats.map(([icon, value, label]) => (
          <article className="stat-card" key={label}>
            <div className="stat-icon">{icon}</div>
            <div><strong>{value}</strong><span>{label}</span></div>
          </article>
        ))}
      </div>
    </section>
  )
}

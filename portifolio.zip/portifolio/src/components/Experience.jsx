import { useEffect, useRef, useState } from 'react'

const experienceCode = [
  'const experience = {',
  '  current: {',
  '    company: "HAPPY WEB",',
  '    role: "Desenvolvedor Web",',
  '    since: "06/2025",',
  '    focus: [',
  '      "Web Development",',
  '      "UX",',
  '      "Client Solutions"',
  '    ]',
  '  },',
  '',
  '  previous: {',
  '    company: "LIMBER SOFTWARE",',
  '    role: "Desenvolvedor Web Júnior",',
  '    period: "03/2022 - 01/2024",',
  '    stack: [',
  '      "Angular",',
  '      "TypeScript",',
  '      "JavaScript",',
  '      "HTML",',
  '      "CSS",',
  '      "REST APIs",',
  '      "SQL"',
  '    ]',
  '  },',
  '',
  '  mindset: "Clean Code + evolução contínua"',
  '};',
  '',
  'export default experience;'
].join('\n')

const jobs = [
  {
    date: '06/2025 – Atual',
    role: 'Desenvolvedor Web / Desenvolvimento de Sites',
    company: 'HAPPY WEB - Pato Branco, PR',
    items: [
      'Desenvolvimento, manutenção e evolução de sites e aplicações web.',
      'Implementação de melhorias conforme necessidades dos clientes.',
      'Participação na criação e lançamento de projetos.',
      'Reuniões para levantamento de requisitos e identificação de melhorias.',
      'Soluções voltadas à experiência do usuário e objetivos do cliente.'
    ]
  },
  {
    date: '03/2022 – 01/2024',
    role: 'Desenvolvedor Web Júnior / Estagiário de Desenvolvimento',
    company: 'LIMBER SOFTWARE',
    items: [
      'Atuação em projetos em produção, desenvolvimento, manutenção e suporte de aplicações web.',
      'Desenvolvimento de funcionalidades e correção de bugs.',
      'Angular, TypeScript, JavaScript, HTML e CSS.',
      'Integração e consumo de APIs.',
      'Manipulação de bancos de dados relacionais e não relacionais e consultas SQL.',
      'Testes, homologações e aplicação de Clean Code.',
      'Uso de Inteligência Artificial para otimização de processos.'
    ]
  }
]

function colorizeCode(text) {
  const escaped = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')

  return escaped
    .replace(/(".*?")/g, '<span class="tok-string">$1</span>')
    .replace(/\b(const|export|default)\b/g, '<span class="tok-keyword">$1</span>')
    .replace(/\b(current|previous|company|role|since|focus|period|stack|mindset)\b(?=\s*:)/g, '<span class="tok-prop">$1</span>')
}

export default function Experience() {
  const panelRef = useRef(null)
  const screenRef = useRef(null)
  const [typed, setTyped] = useState('')

  useEffect(() => {
    const panel = panelRef.current
    if (!panel) return

    let timer
    let started = false

    const observer = new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting) || started) return
      started = true

      let i = 0
      timer = window.setInterval(() => {
        i = Math.min(i + 2, experienceCode.length)
        setTyped(experienceCode.slice(0, i))
        if (screenRef.current) screenRef.current.scrollTop = screenRef.current.scrollHeight
        if (i >= experienceCode.length) window.clearInterval(timer)
      }, 18)

      observer.disconnect()
    }, { threshold: .25 })

    observer.observe(panel)

    return () => {
      observer.disconnect()
      if (timer) window.clearInterval(timer)
    }
  }, [])

  return (
    <section className="content-section reveal" id="experiencia">
      <div className="section-heading">
        <div className="section-kicker"><span></span>EXPERIÊNCIA PROFISSIONAL</div>
        <div className="section-side">// MINHA TRAJETÓRIA</div>
      </div>

      <div className="experience-layout">
        <div className="timeline">
          {jobs.map((job) => (
            <article className="timeline-item" key={`${job.company}-${job.date}`}>
              <div className="timeline-date">{job.date}</div>
              <div className="timeline-marker"></div>
              <div className="timeline-body">
                <h4>{job.role}</h4>
                <strong>{job.company}</strong>
                <ul>{job.items.map((item) => <li key={item}>{item}</li>)}</ul>
              </div>
            </article>
          ))}
        </div>

        <aside className="experience-code" aria-label="Terminal de código animado" ref={panelRef}>
          <div className="code-window">
            <div className="code-top">
              <div className="code-dots"><i></i><i></i><i></i></div>
              <span>experience.ts</span>
              <small>● LIVE</small>
            </div>
            <pre className="code-screen" ref={screenRef}>
              <code dangerouslySetInnerHTML={{ __html: colorizeCode(typed) }} />
              <span className="code-cursor"></span>
            </pre>
          </div>
        </aside>
      </div>
    </section>
  )
}

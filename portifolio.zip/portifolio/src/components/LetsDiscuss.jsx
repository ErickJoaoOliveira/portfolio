import { useEffect, useRef } from 'react'

export default function LetsDiscuss() {
  const stageRef = useRef(null)
  const cursorRef = useRef(null)

  useEffect(() => {
    const stage = stageRef.current
    const cursor = cursorRef.current
    if (!stage || !cursor) return

    const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)')
    if (!finePointer.matches) return

    let tx = 0
    let ty = 0
    let cx = 0
    let cy = 0
    let raf = 0

    const rect = stage.getBoundingClientRect()
    tx = cx = rect.width / 2
    ty = cy = rect.height / 2

    const animate = () => {
      cx += (tx - cx) * .16
      cy += (ty - cy) * .16
      cursor.style.transform = `translate3d(${cx}px, ${cy}px, 0) translate(-50%, -50%)`
      raf = requestAnimationFrame(animate)
    }

    const enter = () => stage.classList.add('cursor-active')
    const leave = () => stage.classList.remove('cursor-active')
    const move = (event) => {
      const r = stage.getBoundingClientRect()
      tx = event.clientX - r.left
      ty = event.clientY - r.top

      const px = Math.max(0, Math.min(100, (tx / r.width) * 100))
      const py = Math.max(0, Math.min(100, (ty / r.height) * 100))

      stage.style.setProperty('--mx', `${px}%`)
      stage.style.setProperty('--my', `${py}%`)
    }

    stage.addEventListener('pointerenter', enter)
    stage.addEventListener('pointerleave', leave)
    stage.addEventListener('pointermove', move)
    raf = requestAnimationFrame(animate)

    return () => {
      cancelAnimationFrame(raf)
      stage.removeEventListener('pointerenter', enter)
      stage.removeEventListener('pointerleave', leave)
      stage.removeEventListener('pointermove', move)
    }
  }, [])

  return (
    <section className="discuss-section reveal" id="vamos-conversar">
      <div className="discuss-label"><span></span>VAMOS CONVERSAR?</div>

      <div className="discuss-stage" ref={stageRef}>
        <div className="discuss-words" aria-hidden="true">
          <div className="discuss-line">
            <span className="outline-text">LET'S</span>
            <span className="outline-text">DISCUSS</span>
          </div>
          <div className="discuss-line discuss-line-accent">
            <span className="outline-text accent-outline">LET'S</span>
            <span className="outline-text accent-outline">DISCUSS</span>
          </div>
        </div>

        <a
          className="discuss-cursor"
          ref={cursorRef}
          href="mailto:erickkoliveira93@gmail.com"
          aria-label="Entrar em contato por e-mail"
        >
          <span className="cursor-arrow">↗</span>
          <strong>Contact Me</strong>
        </a>
      </div>

      <div className="discuss-bottom">
        <div>
          <small>E-MAIL</small>
          <a href="mailto:erickkoliveira93@gmail.com">erickkoliveira93@gmail.com</a>
        </div>
        <div>
          <small>WHATSAPP</small>
          <a href="https://wa.me/5546988345549" target="_blank" rel="noopener noreferrer">+55 (46) 98834-5549</a>
        </div>
        <div>
          <small>GITHUB</small>
          <a href="https://github.com/ErickJoaoOliveira" target="_blank" rel="noopener noreferrer">@ErickJoaoOliveira</a>
        </div>
      </div>
    </section>
  )
}

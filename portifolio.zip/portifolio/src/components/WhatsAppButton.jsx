import { WhatsAppIcon } from './Icons'
import { trackEvent } from '../analytics'

export default function WhatsAppButton() {
  return (
    <a
      className="whatsapp-float"
      href="https://wa.me/5546988345549"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar comigo pelo WhatsApp"
      title="Falar comigo pelo WhatsApp"
      onClick={() => trackEvent('whatsapp_click', { location: 'floating_button' })}
    >
      <WhatsAppIcon />
      <span>WhatsApp</span>
    </a>
  )
}

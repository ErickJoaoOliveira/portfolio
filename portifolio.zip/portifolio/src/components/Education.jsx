import { asset } from '../utils'

export default function Education() {
  return (
    <section className="content-section reveal" id="formacao">
      <div className="section-heading">
        <div className="section-kicker"><span></span>FORMAÇÃO</div>
        <div className="section-side">// EDUCAÇÃO</div>
      </div>

      <div className="education-grid">
        <article className="education-card">
          <div className="edu-logo-wrap">
            <img className="edu-logo" src={asset('cepb.webp')} alt="Logo CEPB" width="2048" height="682" loading="lazy" decoding="async" />
          </div>
          <div>
            <h4>Técnico em Informática</h4>
            <p>CEPB</p>
            <span>Conclusão: 2024</span>
          </div>
        </article>

        <article className="education-card education-wide">
          <div className="edu-logos">
            <div className="edu-logo-wrap">
              <img className="edu-logo" src={asset('unimater.webp')} alt="Logo UNIMATER" width="1885" height="834" loading="lazy" decoding="async" />
            </div>
            <div className="edu-logo-wrap">
              <img className="edu-logo" src={asset('alura.webp')} alt="Logo Alura" width="2048" height="682" loading="lazy" decoding="async" />
            </div>
          </div>
          <div>
            <h4>Cursos e Programas</h4>
            <p>Programa NewDev - UNIMATER</p>
            <span>Desenvolvimento de software e lógica de programação. Cursos complementares em desenvolvimento web.</span>
          </div>
        </article>

        <article className="education-card">
          <div className="edu-icon">◎</div>
          <div>
            <h4>IDIOMAS</h4>
            <p>Inglês</p>
          </div>
        </article>
      </div>
    </section>
  )
}

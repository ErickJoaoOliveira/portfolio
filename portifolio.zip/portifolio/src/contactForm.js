export function buildContactPayload(form) {
  return new URLSearchParams({
    'form-name': 'contact',
    'bot-field': '',
    name: form.name.trim(),
    email: form.email.trim(),
    subject: form.subject.trim(),
    message: form.message.trim()
  })
}

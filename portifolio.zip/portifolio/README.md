# Portfólio Erick — React + Vite — Netlify

Versão preparada para produção, com Netlify Forms e Google Analytics 4.

## O que foi corrigido no formulário

Esta versão usa duas definições estáticas para o Netlify detectar o formulário:

- blueprint dentro de `index.html`
- blueprint dedicado em `public/form-contact.html`

O formulário React envia via AJAX para `/form-contact.html` usando
`application/x-www-form-urlencoded`.

Também foi removido o rewrite SPA global porque este projeto não usa React Router.
Isso evita interferência no endpoint de POST.

## IMPORTANTE: uma configuração do Netlify é obrigatória

No painel do Netlify:

**Forms → Enable form detection**

Se já estiver habilitado, não precisa mexer.

Depois de habilitar, faça um NOVO deploy. O Netlify só detecta formulários em deploys feitos depois da ativação.

## Deploy

Você pode enviar a pasta inteira deste projeto pelo Netlify Drop estando logado.
O Netlify detecta Vite e faz o build.

Ou localmente:

```bash
npm install
npm test
npm run build
```

Depois envie a pasta `dist`.

## Como confirmar que funcionou

Depois do deploy:

1. Abra **Netlify → Forms**
2. Deve aparecer um formulário chamado **contact**
3. Só depois teste o botão **Enviar mensagem**
4. As submissões aparecerão em `Forms → contact`

## Google Analytics

Já configurado com:

`G-EZ22Z4XZHZ`

A variável está em `.env.production`.

Eventos:
- `contact_submit`
- `whatsapp_click`
- `github_click`

## Domínio

Canonical:
`https://erickkoliveira.com.br/`


## Estratégia SEO de palavras-chave

A página foi otimizada de forma natural para buscas como:

- desenvolvedor de sites
- programador
- desenvolvedor web
- programador Front-End
- criação de sites
- desenvolvimento de sites
- desenvolvedor de sites em Pato Branco
- programador em Pato Branco

Não foi usada a tag `meta keywords`, porque ela é ignorada pelo Google.
As palavras principais aparecem em title, description, conteúdo visível e dados estruturados.

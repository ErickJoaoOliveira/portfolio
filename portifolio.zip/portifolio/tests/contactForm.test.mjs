import test from 'node:test'
import assert from 'node:assert/strict'
import { buildContactPayload } from '../src/contactForm.js'

test('payload é compatível com Netlify Forms', () => {
  const payload = buildContactPayload({
    name: ' Erick ',
    email: ' erick@example.com ',
    subject: ' Projeto ',
    message: ' Olá '
  })

  assert.equal(payload.get('form-name'), 'contact')
  assert.equal(payload.get('bot-field'), '')
  assert.equal(payload.get('name'), 'Erick')
  assert.equal(payload.get('email'), 'erick@example.com')
  assert.equal(payload.get('subject'), 'Projeto')
  assert.equal(payload.get('message'), 'Olá')
})
